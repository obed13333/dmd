const discord = require("discord.js")

exports.run = (client, message, args) => {
  
  let sy = args.join(' ')
  message.channel.send(`https://discord.com/oauth2/authorize?client_id=944031462934585414&scope=bot%20applications.commands&permissions=2146958847`)
  message.delete()
  message.react('✅')
  message.channel.send(sy)
}


const Discord = require("discord.js");

module.exports.run = async (client , message , args) => {
    /*
    var stringlink = 'Invite link'
    
    var lank =`https://discordapp.com/oauth2/authorize?&client_id=${client.user.id}&scope=bot&permissions=8`
    var embed = new Discord.RichEmbed()
    .setDescription('Click on '+ "url":lank)
    .setColor(0xff0000)
    .setTimestamp()
message.author.send(embed).then(message.channel.send(`I've sent you MOON's invite link in DM's.`))
*/
message.author.send({embed: {
    color:0xff0000,
    author: {
      name: client.user.username,
      icon_url: client.user.avatarURL,
    },
    title: "Invitame",
    url: "https://discord.com",
    description: "**SG CB Software.**",
      
        name: "Invite link",
        value: `**Clickeame** [invite link](https://discordapp.com/api/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8
        ) **Invita a sgcb bot a tu server!**.`
      },
    
    timestamp: new Date(),
    footer: {
      icon_url: client.user.avatarURL,
      text: "©"
    }
  
}).then(message.channel.send({embed:{
    color:0xff0000,
    fields: [{
        name: message.author.username + " " +"enlace de invitación solicitado.",
        value: `**He enviado un enlace de invitación a tus DM** __**${message.author.username}**__.  `
    }]
}}))

}