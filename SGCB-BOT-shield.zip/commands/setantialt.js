const db = require("quick.db")
const discord = require("discord.js")

exports.run = async (client, message, args) => {

  
  let option = args[0]
  if(!option){
    const embed = new discord.MessageEmbed()
    .setAuthor("Opción de sistema antialterno")
    .setColor("RANDOM")
    .setDescription("Escriba `on` para anti alt habilitado\nEscriba `off` para deshabilitar anti alt")
    .setTimestamp()
    return message.channel.send(embed)
  }
  
  let logs = message.mentions.channels.first()
  let database = db.get(`antialt.${message.guild.id}`)
  
  if(option.toLowerCase() === "on"){
    if(database){
      return message.channel.send("Este servidor ya configuró el sistema anti alt.");
    }
    let days = args[2]
    if(!logs){
      return message.channel.send("Mencione los canales que configurará como registros antialt.")
    }
    if(!days){
      return message.channel.send("¿Cuántos días de edad permitirá que un nuevo miembro se una a su servidor?")
    }
    if(isNaN(days)){
      return message.channel.send("La opción de días debe ser un número")
    }
    
    db.set(`antialt.${message.guild.id}`, logs.id)
    db.set(`altdays.${message.guild.id}`, days)
    const embed = new discord.MessageEmbed()
    .setAuthor("Anti alt habilitado")
    .setColor("RANDOM")
    .setDescription(`${message.author.tag} se ha habilitado el sistema anti alt`)
    .setTimestamp()
    return message.channel.send(embed)
  }else if(option.toLowerCase() === "off"){
    if(!database){
      return message.channel.send("Este servidor no está configurado como sistema anti alt.");
    }
    db.delete(`antialt.${message.guild.id}`)
    db.delete(`altdays.${message.guild.id}`)
    
    const embed = new discord.MessageEmbed()
    .setAuthor("Anti alt deshabilitado")
    .setColor("RANDOM")
    .setDescription(`${message.author.tag} se ha deshabilitado el sistema anti alt`)
    .setTimestamp()
    return message.channel.send(embed)
  }
  
}