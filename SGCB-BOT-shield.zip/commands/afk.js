const Discord = require('discord.js'),
  	  db = require('quick.db');

exports.run = async(client, message, args, tools) => {

  // Create a new 'AFK' table w/ Quick.db
  const status = new db.table('AFKs');

  // Fetch user object from that table
  let afk = await status.fetch(message.author.id);

  // Form Embed
	const embed = new Discord.MessageEmbed()
    .setColor(0xffffff)

  if (!afk) { // Run if they are NOT afk, or afk is null
    embed.setFooter('Ahora estás AFK.'); // Modify Embed
	  embed.set
    // Add the user to the AFK pool
    status.set(message.author.id, args.join(' ') || `Lo siento, ${message.author.username} esta en AFK.`);
  } else { // Run if they ARE afk
    embed.setFooter('Ya no estás AFK.'); // Modify Embed
    // Remove the user from the AFK pool
    status.delete(message.author.id);
  }

  // Send Embed
  message.channel.send(embed);

}
