const discord = require("discord.js");

exports.run = async(client, message, args) => {
  
  if(!message.member.hasPermission("ADMINISTRATOR")) {
    return message.channel.send("No tienes suficientes permisos para usar este comando");
  }
  
  let user = message.mentions.users.first()
  if(!user) {
    return message.channel.send("Porfavor mencione a un usuario a quien baneara")
  }
  
  if(user.id === message.author.id) {
    return message.channel.send("No te puedes banear tu mismo");
  } else if(user.id === message.guild.owner.user.id) {
    return message.channel.send("No puedes banear al propietario del servidor.");
  } else if(user.id === client.user.id) {
    return message.channel.send("No puedes banearme :(");
  }

  let reason = args.slice(1).join(" ") || "Sin motivo específicado";
  let member = message.guild.members.cache.get(user.id)
  
  member
  .ban(user, {reason: reason})
  .then(() => {
    return message.channel.send(`No tengo suficientes permisos para banear a este usuario: ${user.tag}, Razon: ${reason}, ID: ${user.id}`)
  })
  .catch(() => {
    return message.channel.send("No tengo suficientes permisos para banear a este usuario");
  })
}
