
  
const Discord = require('discord.js')

module.exports.run = async(client, message, args) => {
    var choices = [
        '● **Es cierto**',
        '● **It is decidedly so**',
        '● **Sin duda**',
        '● **sí definitivamente**',
        '● **Puedes confiar en ello**',
        '● **Usted puede contar con él**',
        '● **Como yo lo veo, sí**',
        '● **Más probable**',
        '● **Perspectiva bueno**',
        '● **Sí**',
        '● **Las señales apuntan a que sí**',
        '● **Absolutamente**',
        '● **Respuesta confusa, intenta otra vez**',
        '● **Pregunta de nuevo más tarde**',
        '● **Mejor no decirte ahora**',
        '● **No se puede predecir ahora**',
        '● **Concéntrate y pregunta otra vez**',
        "● **No cuentes con eso**",
        '● **Mi respuesta es no**',
        '● **Mis fuentes dicen que no**',
        '● **Perspectiva no tan bueno**',
        '● **Muy dudoso**',
        "● **Las posibilidades no son buenas**"

        
    ]
	const embed = new Discord.MessageEmbed()
    .setAuthor('8ball','http://www.pngmart.com/files/3/8-Ball-Pool-PNG-Photos.png')
    .setThumbnail('https://vignette.wikia.nocookie.net/uncyclopedia/images/4/40/8ball.png/revision/latest?cb=20131030182451')
    .setDescription(`${choices[Math.floor(Math.random() * choices.length)]}`)
    .setColor(000000)

    message.channel.send(embed)
   

}


module.exports.help = {
    name: "8ball",
    description: "8Ball es un comando que se utiliza para adivinar o pedir consejo.",
    usage: '8ball [Tu pregunta]'
}