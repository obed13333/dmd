const { MessageEmbed } = require('discord.js');
const os = require('os');
const moment = require("moment")


exports.run = async (client, message, args) => {
		const embed = new MessageEmbed()
			.setThumbnail(client.user.displayAvatarURL())
			.setTitle('Estadísticas del bot')
			.setColor('#000000')
			.addFields(
				{
					name: '🌐 Servidores',
					value: `Sirviendo ${client.guilds.cache.size} servidores.`,
					inline: true,
				},
				{
					name: '📺 Canales',
					value: `Sirviendo ${client.channels.cache.size} canales en total.`,
					inline: true,
				},
				{
					name: '👥 Usuarios del servidor',
					value: `Sirviendo ${client.users.cache.size} usuarios`,
					inline: true,
				},
				{
					name: '⏳ Ping',
					value: `${Math.round(client.ws.ping)}ms`,
					inline: true,
				},
				{
					name: 'Información del servidor',
					value: `Núcleos: ${os.cpus().length}`,
					inline: true,
				},
        {
          name: 'Bot creado en',
          value: `${client.user.createdAt}`,
          inline: true,
        }

			)
			.setFooter(`Pedido por${message.author.tag}`, message.author.displayAvatarURL());

		return message.channel.send(embed);

}
