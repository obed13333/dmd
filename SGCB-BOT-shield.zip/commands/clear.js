const discord = require("discord.js")

exports.run = (client, message, args) => {
  
  let cr = args[0]
  if(!cr)return message.reply("¿Cuántos mensajes borrarás?")
  if(isNaN(cr))return message.reply("El argumento no es numero")
  if(cr > 100)return message.reply("No puede borrar mensajes de más de 100 mensajes")
  if(cr < 1)return message.reply("No puedes borrar el mensaje debajo de 1 mensaje")
  
  message.channel.bulkDelete(cr)
  message.channel.send(`${message.author} has been clear ${cr} message`).then(m => {
    m.delete({timeout: 3000})
  })
}
