const discord = require("discord.js")

exports.run = (client, message, args) => {
  
  let sy = args.join(' ')
  if(!sy)return message.channel.send(`${message.author} por favor dame un mensaje`)
  message.delete()
  message.channel.send(sy)
}