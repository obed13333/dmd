const discord = require("discord.js");
const novelcovid = require("novelcovid");

exports.run = async(client, message, args) => {
  
  let text = args.join(' ')
  if(!text){
    let corona = await novelcovid.all()
    
    const embed = new discord.MessageEmbed()
    .setAuthor("Estado global de Covid-19")
    .setColor("RANDOM")
    .addField("Casos Totales",corona.cases.toLocaleString(),true)
    .addField("Muertes totales",corona.deaths.toLocaleString(),true)
    .addField("Total recuperados",corona.recovered.toLocaleString(),true)
    .addField("Casos de hoy",corona.todayCases.toLocaleString(),true)
    .addField("Muertes de hoy",corona.todayDeaths.toLocaleString(),true)
    .addField("Hoy recuperados",corona.todayRecovered.toLocaleString(),true)
    .addField("Casos activos",corona.active.toLocaleString(),true)
    .addField("Casos Críticos",corona.critical.toLocaleString(),true)
    .addField("Actualizaciones",corona.updated.toLocaleString(),true)
    .setFooter("Mantente seguro/a")
    .setTimestamp()
    message.channel.send(embed)
  }else{
    let corona = await novelcovid.countries({country: args.join(' ')})
    
    if(corona.country === undefined)return message.channel.send(`${message.author} I Can't Find Country Called: **${args.join(' ')}**`)
    
    const embed = new discord.MessageEmbed()
    .setAuthor(`${corona.country}[${corona.iso2}]`,corona.countryInfo.flag)
    .setThumbnail(corona.countryInfo.flag)
    .setColor("RANDOM")
    .addField("Total Cases",corona.cases.toLocaleString(),true)
    .addField("Total Deaths",corona.deaths.toLocaleString(),true)
    .addField("Total Recovered",corona.recovered.toLocaleString(),true)
    .addField("Today Cases",corona.todayCases.toLocaleString(),true)
    .addField("Today Deaths",corona.todayDeaths.toLocaleString(),true)
    .addField("Today Recovered",corona.todayRecovered.toLocaleString(),true)
    .addField("Casos activos",corona.active.toLocaleString(),true)
    .addField("Casos Críticos",corona.critical.toLocaleString(),true)
    .addField("Mantente seguro",corona.updated.toLocaleString(),true)
    .setFooter("Mantente seguro/a")
    .setTimestamp()
    message.channel.send(embed)
  }
}
