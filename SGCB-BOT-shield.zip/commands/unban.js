const discord = require("discord.js");

exports.run = async (client, message, args) => {
  
  let user = args[0];
  if(!user) {
    return message.channel.send("Proporcione la identificación de usuario, ¿quiere desbanear?");
  }
  
  if(user === message.author.id) {
    return message.channel.send("No puedes desbanearte");
  } else if(user === message.guild.owner.user.id) {
    return message.channel.send("No puedes deshacer el dueño del servidor.");
  } else if(user === client.user.id) {
    return message.channel.send("No puedes desbanearme:(");
  }
  
  let reason = args.slice(1).join(" ") || "Sin motivo";
  let userUnban = client.users.cache.get(user);
  
  message.guild.members
  .unban(user, {reason: reason})
  .then(() => {
    return message.channel.send(`Has desbaneado al usuario: ${userUnban.tag}, Razon: ${reason}`)
  })
  .catch(() => {
    return message.channel.send("No puedo encontrar el usuario proporcionado !");
  })
}
