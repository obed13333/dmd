const discord = require("discord.js")
const ownersId = [,]


exports.run = async (client, message, args) => {
  
  if (message.author.id !== ownersId){
    return message.channel.send("Lo siento, solo Servidores que necesitan maxima seguridad puede usar este commando.")
  }
  let pos = message.channel.position
  
  message.channel.clone().then(c => {
    message.channel.delete()
    c.setPosition(pos)
    c.send("Este canal ha sido bombardeado\nhttps://imgur.com/LIyGeCR")
  })
}
