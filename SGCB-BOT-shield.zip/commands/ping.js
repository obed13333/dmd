const discord = require("discord.js")

exports.run = (client, message, args) => {
  message.channel.send("Pongg:ping_pong:")
}
